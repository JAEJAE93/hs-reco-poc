from flask import Flask, render_template, request
import json, requests
from datetime import datetime

def get_current_time_formatted():
    return datetime.now().strftime("%Y%m%d%H%M%S")


with open('./data/json_pci.json', 'r') as f:
    pci_data = json.load(f)
    
pci_headers = pci_data['headers']

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/button-pressed', methods=['POST'])
def button_pressed():
    button_nm = request.form['button']
    url_pci3026 = pci_data['url']['url_pci3026']
    current_time = get_current_time_formatted() # 현재시간
    said = pci_data['pci_3026_0']['said'] # 테스트 셋탑
    partner_code = '1104'
    
    if button_nm == '건강':
        maid = pci_data['pci_3026_9']['maid']
    elif button_nm == '음식':
        maid = pci_data['pci_3026_0']['maid']
    elif button_nm == '패션':
        maid = pci_data['pci_3026_5']['maid']
    elif button_nm == '셋탑박스':
        maid = pci_data['pci_3026_stb']['maid']
        

        
    json_data = {
            'said':said,
            'maid':maid,
            'reg_date': current_time,
            'partner_code': partner_code
        }
    
    response = requests.post(url_pci3026, json=json_data, headers=pci_headers)
       
    if response.status_code == 200:
        # 성공적으로 요청이 처리됨
        result = response.json()
        print(result)
        print(current_time)
        pci_pid = result['data']['p_id']
        
        if button_nm == '셋탑박스':
            result_str = f'셋탑박스 체크인 초기화'
        else:
            result_str = f'PID 체크인: {pci_pid}'
        return render_template('button-pressed.html', result_str=result_str)
    else:
        # 요청이 실패됨
        print('POST 요청 실패:', response.status_code)

if __name__ == '__main__':
    # app.run(debug=True)
    app.run(host='0.0.0.0', port=5000, debug=True)
